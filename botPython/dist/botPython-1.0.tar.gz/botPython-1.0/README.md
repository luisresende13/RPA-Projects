# Python Bot

Python package for a BotCity bot.


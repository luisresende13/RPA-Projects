# WebBot

Bot built with BotCity web framework.

